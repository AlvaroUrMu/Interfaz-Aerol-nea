package org.ivz.pmdm.aurbano.ejerciciointerfazaerolinea;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    int[] factura;
    Button btBackToSecond, btEnd;
    TextView tvFactura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        tvFactura = findViewById(R.id.tvFactura);
        //Intent intent = getIntent();
        Bundle bundle = getIntent().getExtras();

        factura = bundle.getIntArray("factura");

        tvFactura.setText(facturacion(factura));

        btBackToSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToSecond = new Intent(ThirdActivity.this, SecondActivity.class);
                startActivity(intentToSecond);
            }
        });

        btEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToMain = new Intent(ThirdActivity.this, MainActivity.class);
                startActivity(intentToMain);
            }
        });
    }

    public String facturacion(int[] factura){
        return "Origen = " + factura[0] + "\n" +
                "Destino = " + factura[1] + "\n" +
                "Fecha = " + factura[2] + "\n" +
                "Primera clase = " + factura[3] + " €" + "\n" +
                "Ventanilla = " + factura[4] + " €" + "\n" +
                "Mascota = " + factura[5] + " €" + "\n" +
                "Desayuno = " + factura[6] + " €" + "\n" +
                "Almuerzo = " + factura[7] + " €" + "\n" +
                "Cena = " + factura[8] + " €" + "\n" +
                "Seguro = " + factura[9] + " €";
    }
}