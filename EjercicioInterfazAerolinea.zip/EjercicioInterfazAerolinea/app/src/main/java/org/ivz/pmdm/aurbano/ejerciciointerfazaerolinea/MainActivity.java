package org.ivz.pmdm.aurbano.ejerciciointerfazaerolinea;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.snackbar.Snackbar;
import com.muddzdev.styleabletoastlibrary.StyleableToast;

public class MainActivity extends AppCompatActivity {

    //Crear componentes
    int[] factura;
    Button btComprar;
    CoordinatorLayout layout;
    ImageButton ibAccesoPref, btnConfirm, btnCancel;
    Spinner spinOrigen, spinDestino;
    CheckBox cbPrimeraClase, cbVentanilla, cbMascota, cbDesayuno, cbAlmuerzo, cbCena;
    RadioButton rbtSeguroSi, rbtSeguroNo;
    EditText etFecha, etNombre, etApellidos, etDireccion, etTelefono, etEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Iniciar componentes
        initialize();

        toast();
        alertDialog();
        snackbar();
        comprar();
    }

    public void initialize(){
        spinOrigen = findViewById(R.id.spinOrigen);
        spinDestino = findViewById(R.id.spinDestino);
        cbPrimeraClase = findViewById(R.id.cbPrimeraClase);
        cbVentanilla = findViewById(R.id.cbVentanilla);
        cbMascota = findViewById(R.id.cbMascota);
        cbDesayuno = findViewById(R.id.cbDesayuno);
        cbAlmuerzo = findViewById(R.id.cbAlmuerzo);
        cbCena = findViewById(R.id.cbCena);
        rbtSeguroSi = findViewById(R.id.rbtSeguroSi);
        rbtSeguroNo = findViewById(R.id.rbtSeguroNo);
        etFecha = findViewById(R.id.etFecha);
        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etDireccion = findViewById(R.id.etDireccion);
        etTelefono = findViewById(R.id.etTelefono);
        etEmail = findViewById(R.id.etEmail);
    }

    public void toast(){
        StyleableToast.makeText(this, "Bienvenido a Sata", R.style.toast).show();
    }

    public void alertDialog(){
        Button btComprar = findViewById(R.id.btComprar);

        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnConfirm = findViewById(R.id.btnConfirm);
                btnCancel = findViewById(R.id.btnCancel);
                ViewGroup viewGroup = findViewById(R.id.content);

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View view1 = LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog_layout, viewGroup, false);
                builder.setView(view1);

                AlertDialog alertDialog = builder.create();

                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                btnConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        comprar();
                    }
                });
                alertDialog.show();
            }
        });
    }

    public void snackbar(){
        ImageButton ibAccesoPref = findViewById(R.id.ibAccesoPref);

        ibAccesoPref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar snackbar = Snackbar.make(view, "Error al procesar la compra", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(getResources().getColor(R.color.cielo3));
                snackbar.setAction("Reintentar", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(MainActivity.this, "Reintentando...", Toast.LENGTH_SHORT).show();
                    }
                });
                snackbar.show();
            }
        });
    }

    public void intentToSecond(){
        Bundle bundle = new Bundle();
        bundle.putIntArray("factura", factura);

        Intent intentToSecond = new Intent(MainActivity.this, SecondActivity.class);
        intentToSecond.putExtras(bundle);

        startActivity(intentToSecond);
    }

    public boolean comparaLugar(){
        if(spinOrigen.getSelectedItem().toString() == spinDestino.getSelectedItem().toString()){
            return true;
        } else{
            return false;
        }
    }

    public void comprar(){
        Button btComprar = findViewById(R.id.btComprar);

        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(comparaLugar()){
                    Toast.makeText(MainActivity.this, "Debe seleccionar un lugar de destino diferente al de origen", Toast.LENGTH_SHORT).show();
                } else if(!comparaLugar()){
                    intentToSecond();
                }
            }
        });
    }

    public boolean validaDatos(){
        if(etNombre.getText().toString().isEmpty()){
            return false;
        } else if(etApellidos.getText().toString().isEmpty()){
            return false;
        } else if(etDireccion.getText().toString().isEmpty()){
            return false;
        } else if(etTelefono.getText().toString().isEmpty()){
            return false;
        } else if(etEmail.getText().toString().isEmpty()){
            return false;
        } else if(etFecha.getText().toString().isEmpty()){
            return false;
        } else{
            return true;
        }
    }

    //Método para pasar a ASCII
    public int pasaAscii(String cadena){
        int valor = 0;

        for(int i = 0; i < cadena.length(); i++){
            valor += cadena.charAt(i);
        }

        return valor;
    }

    public int[] facturacion(int[] factura){
        factura = new int[10];

        factura[0] = pasaAscii(spinOrigen.getSelectedItem().toString());
        factura[1] = pasaAscii(spinDestino.getSelectedItem().toString());
        factura[2] = pasaAscii(etFecha.getText().toString());

        if(cbPrimeraClase.isChecked()){
            factura[3] = 20;
        } else{
            factura[3] = 0;
        }

        if(cbVentanilla.isChecked()){
            factura[4] = 10;
        } else{
            factura[4] = 0;
        }

        if(cbMascota.isChecked()){
            factura[5] = 20;
        } else{
            factura[5] = 0;
        }

        if(cbDesayuno.isChecked()){
            factura[6] = 15;
        } else{
            factura[6] = 0;
        }

        if(cbAlmuerzo.isChecked()){
            factura[7] = 15;
        } else{
            factura[7] = 0;
        }

        if(cbCena.isChecked()){
            factura[8] = 15;
        } else{
            factura[8] = 0;
        }

        if(rbtSeguroSi.isChecked()){
            factura[9] = 100;
        } else if (rbtSeguroNo.isChecked()){
            factura[9] = 0;
        }

        return factura;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id==R.id.contactoaero){
            Uri uri = Uri.parse("https://www.azoresairlines.pt/en");
            Intent intentToAero = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intentToAero);
        }

        return super.onOptionsItemSelected(item);
    }
}