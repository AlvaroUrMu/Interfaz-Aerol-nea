package org.ivz.pmdm.aurbano.ejerciciointerfazaerolinea;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    int[] factura;
    TextView textView;
    Button btBack, btNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.tvPrecio);

        //Intent intentFromMain = getIntent();
        Bundle bundle = getIntent().getExtras();

        factura = bundle.getIntArray("factura");

        textView.setText(sumaFactura(factura));

        intentBack();

        intent();
        intentNext();
    }

    //Método para pasar información a la tercera actividad
    public void intent(){
        Bundle bundle = new Bundle();
        bundle.putIntArray("factura", factura);

        Intent intentToThird = new Intent(SecondActivity.this, ThirdActivity.class);
        intentToThird.putExtras(bundle);

        startActivity(intentToThird);
    }

    //Método del botón "Atrás"
    public void intentBack(){
        btBack = findViewById(R.id.btBack);

        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToMain = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(intentToMain);
            }
        });
    }

    //Método del botón "Siguiente"
    public void intentNext(){
        btNext = findViewById(R.id.btNext);

        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent();
            }
        });
    }

    //Método para pasar a ASCII
    public int pasaAscii(String cadena){
        int valor = 0;

        for(int i = 0; i < cadena.length(); i++){
            valor += (int)cadena.charAt(i);
        }
        return valor;
    }

    //Método para sumar toda la factura
    public int sumaFactura(int[] factura){
        int suma = 0;

        for(int i = 0; i < factura.length; i++){
            suma += factura[i];
        }

        return suma;
    }
}